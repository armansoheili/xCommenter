package com.xcomment.android

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class XCommentAccessibilityService : AccessibilityService() {
    private lateinit var windowManager: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("xcomment_settings", Context.MODE_PRIVATE) }
    private var requestId = 0

    private data class AiResult(val ideas: List<String> = emptyList(), val error: String? = null)

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString().orEmpty()
        val inX = pkg.contains("twitter", ignoreCase = true) || pkg == "com.x.android" || pkg.contains("x", ignoreCase = true)
        if (inX) showBubble() else hideBubbleAndPanel()
    }

    override fun onInterrupt() {}

    private fun showBubble() {
        if (bubble != null) return
        val view = TextView(this).apply {
            text = "AI"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setBackgroundResource(R.drawable.bubble_bg)
            elevation = dp(8).toFloat()
            setOnClickListener { openPanel() }
        }
        val params = overlayParams(dp(58), dp(58)).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(14)
            y = dp(170)
        }
        enableDragging(view, params)
        runCatching { windowManager.addView(view, params) }
        bubble = view
    }

    private fun hideBubbleAndPanel() {
        panel?.let { runCatching { windowManager.removeView(it) } }
        bubble?.let { runCatching { windowManager.removeView(it) } }
        panel = null
        bubble = null
    }

    private fun openPanel() {
        val thisRequest = ++requestId
        panel?.let { runCatching { windowManager.removeView(it) } }

        val rootText = extractVisibleText()
        val tweetText = guessTweet(rootText)

        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundResource(R.drawable.panel_bg)
            elevation = dp(10).toFloat()
        }

        val title = TextView(this).apply {
            text = "Reply ideas"
            textSize = 16f
            setTextColor(0xff0f1419.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        p.addView(title)

        val detected = TextView(this).apply {
            text = if (tweetText.isBlank()) {
                "No tweet text detected. Open a post, then tap AI again."
            } else {
                tweetText.take(180)
            }
            textSize = 12f
            setTextColor(0xff536471.toInt())
            setPadding(0, dp(6), 0, dp(10))
        }
        p.addView(detected)

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        p.addView(list)

        val status = TextView(this).apply {
            textSize = 11f
            setTextColor(0xff536471.toInt())
            setPadding(0, 0, 0, dp(8))
        }
        p.addView(status)

        val close = Button(this).apply {
            text = "Close"
            isAllCaps = false
            setOnClickListener { panel?.let { runCatching { windowManager.removeView(it) } }; panel = null }
        }
        p.addView(close)

        val params = overlayParams(dp(330), WindowManager.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(120)
        }
        runCatching { windowManager.addView(p, params) }
        panel = p

        renderIdeas(list, instantIdeas(tweetText), false)
        status.text = "Instant suggestions shown. Waiting for AI…"

        generateAiIdeas(tweetText) { result ->
            if (panel !== p || thisRequest != requestId) return@generateAiIdeas
            if (result.ideas.isNotEmpty()) {
                renderIdeas(list, result.ideas, true)
                status.text = "AI suggestions ready. Tap one to insert."
            } else {
                status.text = result.error ?: "AI did not return suggestions. Check API key/model/settings."
                status.setTextColor(0xffc62828.toInt())
            }
        }
    }

    private fun renderIdeas(container: LinearLayout, ideas: List<String>, ai: Boolean) {
        container.removeAllViews()
        ideas.forEachIndexed { index, text ->
            val b = Button(this).apply {
                this.text = "${index + 1}. ${text.take(130)}"
                textSize = 13f
                isAllCaps = false
                setOnClickListener { insertOrCopy(text) }
            }
            container.addView(b, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(7) })
        }
    }

    private fun insertOrCopy(text: String) {
        val ok = setTextToFocusedEditable(rootInActiveWindow, text)
        if (ok) {
            Toast.makeText(this, "Inserted into reply box", Toast.LENGTH_SHORT).show()
        } else {
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("XComment reply", text))
            Toast.makeText(this, "No focused reply box. Text copied instead.", Toast.LENGTH_LONG).show()
        }
    }

    private fun setTextToFocusedEditable(node: AccessibilityNodeInfo?, text: String): Boolean {
        if (node == null) return false
        if ((node.isFocused || node.isAccessibilityFocused) && node.isEditable) {
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }
        for (i in 0 until node.childCount) {
            if (setTextToFocusedEditable(node.getChild(i), text)) return true
        }
        return false
    }

    private fun generateAiIdeas(tweet: String, callback: (AiResult) -> Unit) {
        val apiKey = prefs.getString("apiKey", "").orEmpty()
        val apiUrl = prefs.getString("apiUrl", "https://api.freemodel.dev/v1/chat/completions").orEmpty()
        val model = prefs.getString("model", "gpt-5.4").orEmpty()

        if (tweet.isBlank()) {
            callback(AiResult(error = "No tweet text detected."))
            return
        }
        if (apiKey.isBlank()) {
            callback(AiResult(error = "API key is missing. Open XComment AI and save your FreeModel key."))
            return
        }
        if (apiUrl.isBlank() || model.isBlank()) {
            callback(AiResult(error = "API URL or model is missing in settings."))
            return
        }

        executor.execute {
            val result = runCatching {
                val body = JSONObject().apply {
                    put("model", model)
                    put("temperature", 0.35)
                    put("max_tokens", 120)
                    put("messages", JSONArray().apply {
                        put(JSONObject().apply {
                            put("role", "system")
                            put("content", "You write short natural X replies. Match tweet language. Return strict JSON only: {\"comments\":[\"reply1\",\"reply2\",\"reply3\"]}")
                        })
                        put(JSONObject().apply {
                            put("role", "user")
                            put("content", tweet.take(900))
                        })
                    })
                }

                val conn = (URL(apiUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 9000
                    readTimeout = 18000
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("Authorization", "Bearer $apiKey")
                    doOutput = true
                }

                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }

                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val raw = if (stream == null) "" else BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
                if (conn.responseCode !in 200..299) {
                    throw RuntimeException("API ${conn.responseCode}: ${raw.take(220)}")
                }
                val content = JSONObject(raw)
                    .getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                val parsed = parseComments(content)
                if (parsed.isEmpty()) throw RuntimeException("AI response could not be parsed: ${content.take(160)}")
                AiResult(ideas = parsed)
            }.getOrElse { e ->
                AiResult(error = "AI failed: ${e.message ?: e.javaClass.simpleName}")
            }
            main.post { callback(result) }
        }
    }

    private fun parseComments(content: String): List<String> {
        val cleaned = content
            .trim()
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()
        return runCatching {
            val objStart = cleaned.indexOf('{')
            val objEnd = cleaned.lastIndexOf('}')
            val json = if (objStart >= 0 && objEnd > objStart) cleaned.substring(objStart, objEnd + 1) else cleaned
            val arr = JSONObject(json).getJSONArray("comments")
            (0 until arr.length()).mapNotNull { i ->
                val item = arr.get(i)
                when (item) {
                    is String -> item.trim()
                    is JSONObject -> item.optString("text").ifBlank { item.optString("reply") }.trim()
                    else -> item.toString().trim()
                }
            }.filter { it.isNotBlank() }.take(3)
        }.getOrElse {
            cleaned.lines()
                .map { it.trim().trim('-', '•', ' ', '"') }
                .filter { it.length > 4 && !it.startsWith("{") && !it.startsWith("}") }
                .take(3)
        }
    }

    private fun instantIdeas(tweet: String): List<String> {
        if (tweet.any { it in '\u0600'..'\u06FF' }) {
            return listOf("دقیقاً همینطوره 👌", "نکته جالبی بود، مخصوصاً بخش آخرش", "به نظرم این موضوع جای بحث بیشتری داره")
        }
        return listOf(
            "Exactly. This is the part people miss.",
            "Interesting point — especially the last part.",
            "This deserves a deeper conversation."
        )
    }

    private fun extractVisibleText(): List<String> {
        val out = mutableListOf<String>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = n.text?.toString()?.trim().orEmpty()
            if (t.length >= 8) out.add(t)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rootInActiveWindow)
        return out.distinct()
    }

    private fun guessTweet(texts: List<String>): String {
        val bad = listOf("reply", "repost", "like", "view", "post", "search", "home", "messages", "notifications", "premium", "following", "for you", "share", "close")
        return texts
            .asSequence()
            .map { it.replace("\n", " ").trim() }
            .filter { it.length in 20..700 }
            .filter { t -> bad.none { t.equals(it, true) || t.contains("$it button", true) } }
            .maxByOrNull { it.length }
            .orEmpty()
    }

    private fun overlayParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    )

    private fun enableDragging(view: View, params: WindowManager.LayoutParams) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX - (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    runCatching { windowManager.updateViewLayout(view, params) }
                    true
                }
                else -> false
            }
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
