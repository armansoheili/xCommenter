# XComment AI Android Starter

Build fix: Java/Kotlin JVM targets are aligned to 17. Android v0.1.2 also shows real AI/API errors instead of staying on loading forever.

A private Android MVP for using FreeModel/OpenAI-compatible API inside the X Android app.

## What it does

- Shows a floating **AI** bubble when you are inside X/Twitter.
- Reads visible screen text through Android Accessibility.
- Generates quick reply ideas using instant fallback + FreeModel API.
- Tapping an idea inserts the selected text into the focused reply box.
- If no reply box is focused, it copies the text to clipboard.

## Important safety/design choice

This starter does **not** auto-submit posts. It inserts the reply text and leaves the final Post/Reply tap to you.
This avoids accidental posting and makes the MVP more stable while we test X's Android UI.

## Setup

1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Run on your Android phone.
4. In the app, set:
   - API URL: `https://api.freemodel.dev/v1/chat/completions`
   - Model: `gpt-5.4` or any fast FreeModel GPT model
   - API key: your new FreeModel key
5. Tap **Allow floating button** and grant overlay permission.
6. Tap **Enable Accessibility Service** and enable **XComment AI Assistant**.
7. Open X, open a tweet/reply composer, tap the floating AI bubble, then tap a reply idea.

## Files to customize next

- `XCommentAccessibilityService.kt`: floating UI, text extraction, insertion logic.
- `MainActivity.kt`: settings page.

## Next phase

After testing on your phone, we can add:

- Better tweet detection from X's current UI tree.
- Automatic opening of the reply composer.
- Optional one-click post, if it works reliably on your device.
- Cleaner native UI with Material components.

## Build APK without Android Studio (GitHub Actions)

1. Create a new GitHub repository.
2. Upload all files from this folder to the repository.
3. Open the repository's **Actions** tab.
4. Select **Build Debug APK**.
5. Click **Run workflow**.
6. When it finishes, open the completed run and download the artifact named **XCommentAI-debug-apk**.
7. Extract the artifact zip and install the APK on your Android phone.

If Android blocks the APK, enable **Install unknown apps** for the app you use to open the APK.
