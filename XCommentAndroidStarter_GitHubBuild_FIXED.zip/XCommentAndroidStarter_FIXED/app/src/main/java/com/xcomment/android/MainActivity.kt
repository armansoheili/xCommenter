package com.xcomment.android

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("xcomment_settings", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(22))
            layoutParams = LinearLayout.LayoutParams(-1, -1)
        }

        val title = TextView(this).apply {
            text = "XComment AI"
            textSize = 24f
            setTextColor(0xff0f1419.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Floating AI reply helper for X. It suggests replies and inserts the selected text into the focused reply box."
            textSize = 14f
            setTextColor(0xff536471.toInt())
            setPadding(0, dp(8), 0, dp(20))
        }
        root.addView(subtitle)

        val apiLabel = label("FreeModel API key")
        root.addView(apiLabel)
        val apiKey = EditText(this).apply {
            hint = "fe_..."
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("apiKey", ""))
        }
        root.addView(apiKey, LinearLayout.LayoutParams(-1, dp(52)))

        root.addView(label("API URL"))
        val apiUrl = EditText(this).apply {
            setSingleLine(true)
            setText(prefs.getString("apiUrl", "https://api.freemodel.dev/v1/chat/completions"))
        }
        root.addView(apiUrl, LinearLayout.LayoutParams(-1, dp(52)))

        root.addView(label("Model"))
        val model = EditText(this).apply {
            setSingleLine(true)
            setText(prefs.getString("model", "gpt-5.4"))
        }
        root.addView(model, LinearLayout.LayoutParams(-1, dp(52)))

        val save = Button(this).apply {
            text = "Save settings"
            setOnClickListener {
                prefs.edit()
                    .putString("apiKey", apiKey.text.toString().trim())
                    .putString("apiUrl", apiUrl.text.toString().trim())
                    .putString("model", model.text.toString().trim())
                    .apply()
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(save, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(16) })

        val overlay = Button(this).apply {
            text = "Allow floating button"
            setOnClickListener {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                startActivity(intent)
            }
        }
        root.addView(overlay, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(10) })

        val accessibility = Button(this).apply {
            text = "Enable Accessibility Service"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(accessibility, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(10) })

        val note = TextView(this).apply {
            text = "How to use: Open X, open a tweet/reply composer, tap the floating AI button, then tap an idea. For safety, this starter inserts text; you press Post manually."
            textSize = 13f
            setTextColor(0xff536471.toInt())
            gravity = Gravity.START
            setPadding(0, dp(18), 0, 0)
        }
        root.addView(note)

        setContentView(root)
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(0xff536471.toInt())
        setPadding(0, dp(12), 0, dp(4))
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
