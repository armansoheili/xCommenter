package com.xcomment.android

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class XCommentAccessibilityService : AccessibilityService() {
    private lateinit var windowManager: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("xcomment_settings", Context.MODE_PRIVATE) }

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString().orEmpty()
        val inX = pkg.contains("twitter", ignoreCase = true) || pkg.contains("x", ignoreCase = true)
        if (inX) showBubble() else hideBubbleAndPanel()
    }

    override fun onInterrupt() {}

    private fun showBubble() {
        if (bubble != null) return
        val view = TextView(this).apply {
            text = "AI"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setBackgroundResource(com.xcomment.android.R.drawable.bubble_bg)
            elevation = dp(8).toFloat()
            setOnClickListener { openPanel() }
        }
        val params = overlayParams(dp(58), dp(58)).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(14)
            y = dp(170)
        }
        enableDragging(view, params)
        windowManager.addView(view, params)
        bubble = view
    }

    private fun hideBubbleAndPanel() {
        panel?.let { runCatching { windowManager.removeView(it) } }
        bubble?.let { runCatching { windowManager.removeView(it) } }
        panel = null
        bubble = null
    }

    private fun openPanel() {
        panel?.let { runCatching { windowManager.removeView(it) } }
        val rootText = extractVisibleText()
        val tweetText = guessTweet(rootText)

        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundResource(com.xcomment.android.R.drawable.panel_bg)
            elevation = dp(10).toFloat()
        }

        val title = TextView(this).apply {
            text = "Reply ideas"
            textSize = 16f
            setTextColor(0xff0f1419.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        p.addView(title)

        val detected = TextView(this).apply {
            text = if (tweetText.isBlank()) "No tweet text detected. Open the tweet or reply composer, then try again." else tweetText.take(180)
            textSize = 12f
            setTextColor(0xff536471.toInt())
            setPadding(0, dp(6), 0, dp(10))
        }
        p.addView(detected)

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        p.addView(list)

        val close = Button(this).apply {
            text = "Close"
            setOnClickListener { panel?.let { runCatching { windowManager.removeView(it) } }; panel = null }
        }
        p.addView(close)

        val params = overlayParams(dp(330), WindowManager.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(120)
        }
        windowManager.addView(p, params)
        panel = p

        renderIdeas(list, instantIdeas(tweetText), false)
        if (tweetText.isNotBlank()) generateAiIdeas(tweetText) { aiIdeas ->
            if (panel === p && aiIdeas.isNotEmpty()) renderIdeas(list, aiIdeas, true)
        }
    }

    private fun renderIdeas(container: LinearLayout, ideas: List<String>, ai: Boolean) {
        container.removeAllViews()
        ideas.forEachIndexed { index, text ->
            val b = Button(this).apply {
                this.text = "${index + 1}. ${text.take(130)}"
                textSize = 13f
                isAllCaps = false
                setOnClickListener { insertOrCopy(text) }
            }
            container.addView(b, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(7) })
        }
        val status = TextView(this).apply {
            text = if (ai) "AI suggestions ready. Tap one to insert." else "Instant suggestions shown. AI is loading…"
            textSize = 11f
            setTextColor(0xff536471.toInt())
        }
        container.addView(status)
    }

    private fun insertOrCopy(text: String) {
        val ok = setTextToFocusedEditable(rootInActiveWindow, text)
        if (ok) {
            Toast.makeText(this, "Inserted into reply box", Toast.LENGTH_SHORT).show()
        } else {
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("XComment reply", text))
            Toast.makeText(this, "No focused reply box. Text copied instead.", Toast.LENGTH_LONG).show()
        }
    }

    private fun setTextToFocusedEditable(node: AccessibilityNodeInfo?, text: String): Boolean {
        if (node == null) return false
        if ((node.isFocused || node.isAccessibilityFocused) && node.isEditable) {
            val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
            return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }
        for (i in 0 until node.childCount) {
            if (setTextToFocusedEditable(node.getChild(i), text)) return true
        }
        return false
    }

    private fun generateAiIdeas(tweet: String, callback: (List<String>) -> Unit) {
        val apiKey = prefs.getString("apiKey", "").orEmpty()
        val apiUrl = prefs.getString("apiUrl", "https://api.freemodel.dev/v1/chat/completions").orEmpty()
        val model = prefs.getString("model", "gpt-5.4").orEmpty()
        if (apiKey.isBlank()) return

        executor.execute {
            val result = runCatching {
                val body = JSONObject().apply {
                    put("model", model)
                    put("temperature", 0.7)
                    put("max_tokens", 180)
                    put("messages", JSONArray().apply {
                        put(JSONObject().apply {
                            put("role", "system")
                            put("content", "Write short, natural X/Twitter replies. Match the tweet language. Return only JSON: {\"comments\":[\"...\",\"...\",\"...\"]}")
                        })
                        put(JSONObject().apply {
                            put("role", "user")
                            put("content", "Tweet: $tweet")
                        })
                    })
                }
                val conn = URL(apiUrl).openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 12000
                conn.readTimeout = 16000
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("Authorization", "Bearer $apiKey")
                conn.doOutput = true
                OutputStreamWriter(conn.outputStream).use { it.write(body.toString()) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val raw = BufferedReader(InputStreamReader(stream)).readText()
                if (conn.responseCode !in 200..299) throw RuntimeException(raw.take(300))
                val content = JSONObject(raw)
                    .getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                parseComments(content)
            }.getOrElse { emptyList() }
            main.post { callback(result) }
        }
    }

    private fun parseComments(content: String): List<String> {
        val trimmed = content.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return runCatching {
            val arr = JSONObject(trimmed).getJSONArray("comments")
            (0 until arr.length()).map { arr.getString(it).trim() }.filter { it.isNotBlank() }.take(3)
        }.getOrElse {
            trimmed.lines().map { it.trim().trim('-', '•', ' ', '"') }.filter { it.length > 4 }.take(3)
        }
    }

    private fun instantIdeas(tweet: String): List<String> {
        if (tweet.any { it in '\u0600'..'\u06FF' }) {
            return listOf("دقیقاً همینطوره 👌", "نکته جالبی بود، مخصوصاً بخش آخرش", "به نظرم این موضوع جای بحث بیشتری داره")
        }
        return listOf("Exactly. This is the part people miss.", "Interesting point — especially the last part.", "This deserves a deeper conversation.")
    }

    private fun extractVisibleText(): List<String> {
        val out = mutableListOf<String>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = n.text?.toString()?.trim().orEmpty()
            if (t.length >= 8) out.add(t)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rootInActiveWindow)
        return out.distinct()
    }

    private fun guessTweet(texts: List<String>): String {
        val bad = listOf("reply", "repost", "like", "view", "post", "search", "home", "messages", "notifications", "premium", "following", "for you")
        return texts
            .asSequence()
            .map { it.replace("\n", " ").trim() }
            .filter { it.length in 20..600 }
            .filter { t -> bad.none { t.equals(it, true) || t.contains("$it button", true) } }
            .maxByOrNull { it.length }
            .orEmpty()
    }

    private fun overlayParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    )

    private fun enableDragging(view: View, params: WindowManager.LayoutParams) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y; touchX = event.rawX; touchY = event.rawY; false
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX - (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    runCatching { windowManager.updateViewLayout(view, params) }
                    true
                }
                else -> false
            }
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
